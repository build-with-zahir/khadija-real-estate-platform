(function () {
    var header = document.querySelector('.site-header');
    function updateHeader() {
        if (!header) return;
        header.classList.toggle('is-scrolled', window.scrollY > 40);
    }
    updateHeader();
    window.addEventListener('scroll', updateHeader);

    var observer = new IntersectionObserver(function (entries) {
        entries.forEach(function (entry) {
            if (entry.isIntersecting) {
                entry.target.classList.add('in-view');
                observer.unobserve(entry.target);
            }
        });
    }, { threshold: 0.12 });
    document.querySelectorAll('.fade-up').forEach(function (el) { observer.observe(el); });

    var lb = document.getElementById('lightbox');
    var lbImg = document.getElementById('lightboxImage');
    var images = [];
    var current = 0;

    function show(index) {
        if (!images.length) return;
        current = (index + images.length) % images.length;
        lbImg.src = images[current];
        lb.classList.add('open');
        lb.setAttribute('aria-hidden', 'false');
    }

    document.querySelectorAll('[data-gallery]').forEach(function (button) {
        button.addEventListener('click', function () {
            try {
                images = JSON.parse(button.getAttribute('data-gallery') || '[]');
            } catch (e) {
                images = [];
            }
            show(parseInt(button.getAttribute('data-index') || '0', 10));
        });
    });

    document.querySelectorAll('[data-lightbox-close]').forEach(function (button) {
        button.addEventListener('click', function () {
            lb.classList.remove('open');
            lb.setAttribute('aria-hidden', 'true');
            lbImg.src = '';
        });
    });
    document.querySelectorAll('[data-lightbox-prev]').forEach(function (button) {
        button.addEventListener('click', function () { show(current - 1); });
    });
    document.querySelectorAll('[data-lightbox-next]').forEach(function (button) {
        button.addEventListener('click', function () { show(current + 1); });
    });
    document.addEventListener('keydown', function (event) {
        if (!lb || !lb.classList.contains('open')) return;
        if (event.key === 'Escape') lb.classList.remove('open');
        if (event.key === 'ArrowLeft') show(current - 1);
        if (event.key === 'ArrowRight') show(current + 1);
    });
})();
