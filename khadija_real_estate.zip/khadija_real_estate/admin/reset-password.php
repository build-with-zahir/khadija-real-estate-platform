<?php
require_once dirname(__DIR__) . '/includes/config.php';
$error = '';
$email = (string)($_SESSION['reset_email'] ?? ($_POST['email'] ?? ''));
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim((string)($_POST['email'] ?? ''));
    $otp = trim((string)($_POST['otp'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $admin = db_fetch_one('SELECT * FROM `admin` WHERE `Email` = ? AND `ResetOtp` = ? AND `OtpExpiry` >= NOW() LIMIT 1', 'ss', [$email, $otp]);
    if ($admin && strlen($password) >= 6) {
        $hash = password_hash($password, PASSWORD_DEFAULT);
        db_execute('UPDATE `admin` SET `Passwd` = ?, `ResetOtp` = NULL, `OtpExpiry` = NULL WHERE `Id` = ?', 'si', [$hash, (int)$admin['Id']]);
        set_flash('success', 'Password reset successfully. Please login.');
        header('Location: ' . site_url('admin/index.php'));
        exit;
    }
    $error = 'Invalid OTP, expired OTP, or password too short.';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Reset Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= h(site_url('assets/css/style.css')) ?>" rel="stylesheet">
    <link href="<?= h(site_url('assets/css/admin.css')) ?>" rel="stylesheet">
</head>
<body class="login-page">
<div class="login-box">
    <h1 class="display-title">Reset Password</h1>
    <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
    <form method="post">
        <?= csrf_field() ?>
        <div class="mb-3"><label class="form-label">Email</label><input class="form-control form-input" type="email" name="email" value="<?= h($email) ?>" required></div>
        <div class="mb-3"><label class="form-label">OTP</label><input class="form-control form-input" name="otp" required></div>
        <div class="mb-3"><label class="form-label">New password</label><input class="form-control form-input" type="password" name="password" required minlength="6"></div>
        <button class="btn btn-gold w-100" type="submit">Reset Password</button>
    </form>
</div>
</body>
</html>
