<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_admin();
header('Content-Type: application/json');

try {
    verify_csrf();
    $type = (string)($_POST['type'] ?? '');
    $id = (int)($_POST['id'] ?? 0);
    if (!in_array($type, ['project', 'property'], true) || $id <= 0) {
        throw new RuntimeException('Invalid request.');
    }
    $table = $type === 'project' ? 'projectimage' : 'propertyimage';
    $row = db_fetch_one("SELECT * FROM `$table` WHERE `Id` = ? LIMIT 1", 'i', [$id]);
    if (!$row) {
        throw new RuntimeException('Image not found.');
    }
    delete_local_upload($row['ImageUrl'] ?? '');
    db_execute("DELETE FROM `$table` WHERE `Id` = ?", 'i', [$id]);
    echo json_encode(['ok' => true]);
} catch (Throwable $e) {
    http_response_code(400);
    echo json_encode(['ok' => false, 'message' => $e->getMessage()]);
}
