<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_admin();

$configs = [
    'areas' => [
        'title' => 'Areas',
        'table' => 'area',
        'name' => 'AreaName',
        'fields' => ['AreaName', 'Slug', 'City', 'State', 'Description', 'ImageUrl'],
        'upload' => 'uploads/general',
    ],
    'categories' => [
        'title' => 'Categories',
        'table' => 'category',
        'name' => 'Name',
        'fields' => ['Name', 'Slug', 'Description', 'ImageUrl'],
        'upload' => 'uploads/general',
    ],
];
$cfg = $configs[$entity] ?? $configs['areas'];
$table = $cfg['table'];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        $old = db_fetch_one("SELECT `ImageUrl` FROM `$table` WHERE `Id` = ? LIMIT 1", 'i', [$id]);
        if ($old) {
            delete_local_upload($old['ImageUrl'] ?? '');
            db_execute("DELETE FROM `$table` WHERE `Id` = ?", 'i', [$id]);
        }
        set_flash('success', $cfg['title'] . ' record deleted.');
        header('Location: ' . site_url('admin/' . ($entity === 'areas' ? 'areas.php' : 'categories.php')));
        exit;
    }

    $id = (int)($_POST['Id'] ?? 0);
    $record = $id ? db_fetch_one("SELECT * FROM `$table` WHERE `Id` = ? LIMIT 1", 'i', [$id]) : null;
    $values = [];
    foreach ($cfg['fields'] as $field) {
        $values[$field] = trim((string)($_POST[$field] ?? ''));
    }
    if ($values['Slug'] === '') {
        $values['Slug'] = slugify($values[$cfg['name']] ?? '');
    }
    $values['ImageUrl'] = upload_single('image_file', $cfg['upload'], $values['ImageUrl'] ?: ($record['ImageUrl'] ?? ''));

    if ($id > 0) {
        $sets = implode(', ', array_map(fn($field) => "`$field` = ?", $cfg['fields']));
        $params = array_values($values);
        $params[] = $id;
        db_execute("UPDATE `$table` SET $sets WHERE `Id` = ?", str_repeat('s', count($values)) . 'i', $params);
        set_flash('success', $cfg['title'] . ' record updated.');
    } else {
        $cols = implode(', ', array_map(fn($field) => "`$field`", $cfg['fields']));
        $placeholders = implode(', ', array_fill(0, count($cfg['fields']), '?'));
        db_execute("INSERT INTO `$table` ($cols) VALUES ($placeholders)", str_repeat('s', count($values)), array_values($values));
        set_flash('success', $cfg['title'] . ' record added.');
    }
    header('Location: ' . site_url('admin/' . ($entity === 'areas' ? 'areas.php' : 'categories.php')));
    exit;
}

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$edit = $editId ? db_fetch_one("SELECT * FROM `$table` WHERE `Id` = ? LIMIT 1", 'i', [$editId]) : null;
$records = db_fetch_all("SELECT * FROM `$table` ORDER BY `Id` DESC");
$pageTitle = $cfg['title'];
$heading = $cfg['title'];
require __DIR__ . '/includes/header.php';
?>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="admin-card p-4">
            <h3 class="display-title"><?= $edit ? 'Edit' : 'Add' ?> <?= h(rtrim($cfg['title'], 's')) ?></h3>
            <form method="post" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="Id" value="<?= (int)($edit['Id'] ?? 0) ?>">
                <?php foreach ($cfg['fields'] as $field): ?>
                    <?php if ($field === 'ImageUrl'): ?>
                        <div class="mb-3">
                            <label>Image URL</label>
                            <input class="form-control" name="ImageUrl" value="<?= h($edit[$field] ?? '') ?>">
                            <input class="form-control mt-2" type="file" name="image_file" accept="image/*">
                        </div>
                    <?php elseif ($field === 'Description'): ?>
                        <div class="mb-3"><label><?= h($field) ?></label><textarea class="form-control" name="<?= h($field) ?>" rows="4"><?= h($edit[$field] ?? '') ?></textarea></div>
                    <?php else: ?>
                        <div class="mb-3"><label><?= h($field) ?></label><input class="form-control" name="<?= h($field) ?>" value="<?= h($edit[$field] ?? '') ?>" <?= $field === $cfg['name'] ? 'required' : '' ?>></div>
                    <?php endif; ?>
                <?php endforeach; ?>
                <button class="btn btn-gold w-100" type="submit">Save</button>
                <?php if ($edit): ?><a class="btn btn-outline-light rounded-0 w-100 mt-2" href="<?= h(site_url('admin/' . ($entity === 'areas' ? 'areas.php' : 'categories.php'))) ?>">Cancel</a><?php endif; ?>
            </form>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="admin-card p-4">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th>Image</th><th>Name</th><th>Slug</th><th class="text-end">Actions</th></tr></thead>
                    <tbody>
                    <?php foreach ($records as $row): ?>
                        <tr>
                            <td><img src="<?= h(image_url($row['ImageUrl'] ?? '')) ?>" alt="" style="width:72px;height:52px;object-fit:cover"></td>
                            <td><?= h($row[$cfg['name']] ?? '') ?></td>
                            <td><?= h($row['Slug'] ?? '') ?></td>
                            <td class="text-end">
                                <a class="btn btn-sm btn-outline-warning rounded-0" href="<?= h(site_url('admin/' . ($entity === 'areas' ? 'areas.php' : 'categories.php') . '?edit=' . (int)$row['Id'])) ?>">Edit</a>
                                <form method="post" class="d-inline" onsubmit="return confirm('Delete this record?')">
                                    <?= csrf_field() ?>
                                    <input type="hidden" name="delete_id" value="<?= (int)$row['Id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger rounded-0">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
