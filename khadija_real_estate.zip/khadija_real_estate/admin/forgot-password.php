<?php
require_once dirname(__DIR__) . '/includes/config.php';
$message = '';
$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim((string)($_POST['email'] ?? ''));
    $admin = db_fetch_one('SELECT * FROM `admin` WHERE `Email` = ? LIMIT 1', 's', [$email]);
    if ($admin) {
        $otp = (string)random_int(100000, 999999);
        $expiry = date('Y-m-d H:i:s', time() + 15 * 60);
        db_execute('UPDATE `admin` SET `ResetOtp` = ?, `OtpExpiry` = ? WHERE `Id` = ?', 'ssi', [$otp, $expiry, (int)$admin['Id']]);
        @mail($email, 'Khadija Real Estate password reset OTP', 'Your OTP is: ' . $otp);
        $_SESSION['reset_email'] = $email;
        header('Location: ' . site_url('admin/reset-password.php'));
        exit;
    }
    $error = 'Email not found.';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Forgot Password</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?= h(site_url('assets/css/style.css')) ?>" rel="stylesheet">
    <link href="<?= h(site_url('assets/css/admin.css')) ?>" rel="stylesheet">
</head>
<body class="login-page">
<div class="login-box">
    <h1 class="display-title">Forgot Password</h1>
    <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
    <?php if ($message): ?><div class="alert alert-success"><?= h($message) ?></div><?php endif; ?>
    <form method="post">
        <?= csrf_field() ?>
        <div class="mb-3"><label class="form-label">Admin email</label><input class="form-control form-input" type="email" name="email" required></div>
        <button class="btn btn-gold w-100" type="submit">Send OTP</button>
    </form>
    <a class="text-warning d-inline-block mt-3" href="<?= h(site_url('admin/index.php')) ?>">Back to login</a>
</div>
</body>
</html>
