<?php
$entity = 'categories';
require __DIR__ . '/manage-entity.php';
