
<?php
$pageTitle = 'Dashboard';
$heading = 'Dashboard';
require_once __DIR__ . '/includes/header.php';

$counts = [
    'Projects' => (int)db_fetch_value('SELECT COUNT(*) FROM `project`'),
    'Properties' => (int)db_fetch_value('SELECT COUNT(*) FROM `property`'),
    'Inquiries' => (int)db_fetch_value('SELECT COUNT(*) FROM `inquiry`'),
    'Testimonials' => (int)db_fetch_value('SELECT COUNT(*) FROM `testimonial`'),
];
?>

<style>
.welcome-card{
background:linear-gradient(90deg,#102544,#162F56);
border:1px solid #1b355c;
border-radius:25px;
padding:40px;
margin-bottom:40px;
}

.welcome-card h1{
font-size:52px;
font-weight:700;
color:#fff;
font-family:'Cormorant Garamond',serif;
}

.welcome-card p{
color:#9fb2c7;
margin-top:10px;
}

.dashboard-card{
background:#07192E;
border:1px solid #162c47;
border-radius:20px;
padding:30px;
height:210px;
transition:.3s;
}

.dashboard-card:hover{
transform:translateY(-6px);
}

.dashboard-card h2{
font-size:52px;
font-weight:700;
color:#fff;
margin-top:30px;
}

.dashboard-card p{
color:#aab8c9;
}

.icon-box{
width:60px;
height:60px;
border-radius:12px;
display:flex;
justify-content:center;
align-items:center;
font-size:22px;
color:white;
}

.gold{background:#d5a13b;}
.cyan{background:#1db6e8;}
.green{background:#17c784;}
.pink{background:#ff2f67;}
</style>

<div class="welcome-card">
    <h1>Welcome To Khadija Real Estate</h1>
    <p>
        Manage projects, properties, categories, areas and enquiries
        from one powerful dashboard.
    </p>
</div>

<h2 class="text-white mb-4">Dashboard Overview</h2>

<div class="row g-4">

    <div class="col-md-6 col-xl-3">
        <div class="dashboard-card">
            <div class="icon-box gold">
                <i class="bi bi-grid"></i>
            </div>

            <h2><?= $counts['Inquiries'] ?></h2>
            <p>Categories</p>
        </div>
    </div>

    <div class="col-md-6 col-xl-3">
        <div class="dashboard-card">
            <div class="icon-box cyan">
                <i class="bi bi-geo-alt"></i>
            </div>

            <h2><?= $counts['Testimonials'] ?></h2>
            <p>Areas</p>
        </div>
    </div>

    <div class="col-md-6 col-xl-3">
        <div class="dashboard-card">
            <div class="icon-box green">
                <i class="bi bi-buildings"></i>
            </div>

            <h2><?= $counts['Projects'] ?></h2>
            <p>Projects</p>
        </div>
    </div>

    <div class="col-md-6 col-xl-3">
        <div class="dashboard-card">
            <div class="icon-box pink">
                <i class="bi bi-house-door"></i>
            </div>

            <h2><?= $counts['Properties'] ?></h2>
            <p>Properties</p>
        </div>
    </div>

</div>

<?php require_once __DIR__ . '/includes/footer.php'; ?>

