<?php
require_once dirname(__DIR__) . '/includes/config.php';
unset($_SESSION['admin_id']);
header('Location: ' . site_url('admin/index.php'));
exit;
