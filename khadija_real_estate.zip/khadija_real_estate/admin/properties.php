<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_admin();
ensure_propertyimage_schema();

function property_selected($a, $b): string { return (string)$a === (string)$b ? 'selected' : ''; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        $property = db_fetch_one('SELECT * FROM `property` WHERE `Id` = ? LIMIT 1', 'i', [$id]);
        if ($property) {
            delete_local_upload($property['ThumbnailImage'] ?? '');
            foreach (db_fetch_all('SELECT `ImageUrl` FROM `propertyimage` WHERE `PropertyId` = ?', 'i', [$id]) as $image) {
                delete_local_upload($image['ImageUrl'] ?? '');
            }
            db_execute('DELETE FROM `property` WHERE `Id` = ?', 'i', [$id]);
        }
        set_flash('success', 'Property deleted.');
        header('Location: ' . site_url('admin/properties.php'));
        exit;
    }

    $id = (int)($_POST['Id'] ?? 0);
    $existing = $id ? db_fetch_one('SELECT * FROM `property` WHERE `Id` = ? LIMIT 1', 'i', [$id]) : null;
    $thumb = upload_single('thumbnail_file', 'uploads/properties', (string)($_POST['ThumbnailImage'] ?: ($existing['ThumbnailImage'] ?? '')));
    $data = [
        'Title' => trim((string)($_POST['Title'] ?? '')),
        'Description' => trim((string)($_POST['Description'] ?? '')),
        'Price' => (string)(float)($_POST['Price'] ?? 0),
        'Bedrooms' => (int)($_POST['Bedrooms'] ?? 0),
        'Bathrooms' => (int)($_POST['Bathrooms'] ?? 0),
        'SquareFeet' => (int)($_POST['SquareFeet'] ?? 0),
        'Address' => trim((string)($_POST['Address'] ?? '')),
        'PropertyType' => trim((string)($_POST['PropertyType'] ?? '')),
        'Status' => trim((string)($_POST['Status'] ?? '')),
        'ThumbnailImage' => $thumb,
        'GalleryImages' => '',
        'Amenities' => implode(',', split_values((string)($_POST['Amenities'] ?? ''))),
        'IsFeatured' => isset($_POST['IsFeatured']) ? 1 : 0,
        'IsActive' => isset($_POST['IsActive']) ? 1 : 0,
        'ProjectId' => ($_POST['ProjectId'] ?? '') !== '' ? (int)$_POST['ProjectId'] : null,
        'CategoryId' => (int)($_POST['CategoryId'] ?? 0),
        'AreaId' => (int)($_POST['AreaId'] ?? 0),
    ];

    if ($id > 0) {
        $sets = implode(', ', array_map(fn($field) => "`$field` = ?", array_keys($data)));
        $params = array_values($data);
        $params[] = $id;
        db_execute("UPDATE `property` SET $sets WHERE `Id` = ?", str_repeat('s', count($data)) . 'i', $params);
        $propertyId = $id;
        set_flash('success', 'Property updated.');
    } else {
        $cols = implode(', ', array_map(fn($field) => "`$field`", array_keys($data)));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $propertyId = db_execute("INSERT INTO `property` ($cols, `CreatedAt`) VALUES ($placeholders, NOW())", str_repeat('s', count($data)), array_values($data));
        set_flash('success', 'Property added.');
    }

    $display = (int)db_fetch_value('SELECT COALESCE(MAX(`DisplayOrder`), -1) + 1 FROM `propertyimage` WHERE `PropertyId` = ?', 'i', [$propertyId]);
    foreach (upload_gallery('gallery', 'uploads/properties') as $image) {
        db_execute('INSERT INTO `propertyimage` (`PropertyId`, `ImageUrl`, `DisplayOrder`) VALUES (?, ?, ?)', 'isi', [$propertyId, $image, $display]);
        $display++;
    }
    header('Location: ' . site_url('admin/properties.php?edit=' . $propertyId));
    exit;
}

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$edit = $editId ? db_fetch_one('SELECT * FROM `property` WHERE `Id` = ? LIMIT 1', 'i', [$editId]) : null;
$gallery = $editId ? db_fetch_all('SELECT * FROM `propertyimage` WHERE `PropertyId` = ? ORDER BY `DisplayOrder`, `Id`', 'i', [$editId]) : [];
$areas = db_fetch_all('SELECT * FROM `area` ORDER BY `AreaName`');
$categories = db_fetch_all('SELECT * FROM `category` ORDER BY `Name`');
$projects = fetch_projects();
$properties = fetch_properties();
$pageTitle = 'Properties';
$heading = 'Properties';
require __DIR__ . '/includes/header.php';
?>
<div class="row g-4">
    <div class="col-xl-5">
        <div class="admin-card p-4">
            <h3 class="display-title"><?= $edit ? 'Edit Property' : 'Add Property' ?></h3>
            <form method="post" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="Id" value="<?= (int)($edit['Id'] ?? 0) ?>">
                <div class="row g-3">
                    <div class="col-12"><label>Title</label><input class="form-control" name="Title" value="<?= h($edit['Title'] ?? '') ?>" required></div>
                    <div class="col-12"><label>Description</label><textarea class="form-control" name="Description" rows="4"><?= h($edit['Description'] ?? '') ?></textarea></div>
                    <div class="col-md-6"><label>Price</label><input class="form-control" type="number" step="0.01" name="Price" value="<?= h((string)($edit['Price'] ?? '')) ?>"></div>
                    <div class="col-md-3"><label>Beds</label><input class="form-control" type="number" name="Bedrooms" value="<?= h((string)($edit['Bedrooms'] ?? '')) ?>"></div>
                    <div class="col-md-3"><label>Baths</label><input class="form-control" type="number" name="Bathrooms" value="<?= h((string)($edit['Bathrooms'] ?? '')) ?>"></div>
                    <div class="col-md-6"><label>Square Feet</label><input class="form-control" type="number" name="SquareFeet" value="<?= h((string)($edit['SquareFeet'] ?? '')) ?>"></div>
                    <div class="col-md-6"><label>Property Type</label><input class="form-control" name="PropertyType" value="<?= h($edit['PropertyType'] ?? 'Apartment') ?>"></div>
                    <div class="col-md-6"><label>Status</label><input class="form-control" name="Status" value="<?= h($edit['Status'] ?? 'Available') ?>"></div>
                    <div class="col-md-6"><label>Project</label><select class="form-select" name="ProjectId"><option value="">None</option><?php foreach ($projects as $project): ?><option value="<?= (int)$project['Id'] ?>" <?= property_selected($edit['ProjectId'] ?? '', $project['Id']) ?>><?= h($project['ProjectName']) ?></option><?php endforeach; ?></select></div>
                    <div class="col-md-6"><label>Category</label><select class="form-select" name="CategoryId" required><option value="">Select</option><?php foreach ($categories as $cat): ?><option value="<?= (int)$cat['Id'] ?>" <?= property_selected($edit['CategoryId'] ?? '', $cat['Id']) ?>><?= h($cat['Name']) ?></option><?php endforeach; ?></select></div>
                    <div class="col-md-6"><label>Area</label><select class="form-select" name="AreaId" required><option value="">Select</option><?php foreach ($areas as $area): ?><option value="<?= (int)$area['Id'] ?>" <?= property_selected($edit['AreaId'] ?? '', $area['Id']) ?>><?= h($area['AreaName']) ?></option><?php endforeach; ?></select></div>
                    <div class="col-12"><label>Address</label><input class="form-control" name="Address" value="<?= h($edit['Address'] ?? '') ?>"></div>
                    <div class="col-12"><label>Thumbnail path</label><input class="form-control" name="ThumbnailImage" value="<?= h($edit['ThumbnailImage'] ?? '') ?>"><input class="form-control mt-2" type="file" name="thumbnail_file" accept="image/*"></div>
                    <div class="col-12"><label>Gallery images</label><input class="form-control" type="file" name="gallery[]" accept="image/*" multiple></div>
                    <div class="col-12"><label>Amenities (one per line)</label><textarea class="form-control" name="Amenities" rows="4"><?= h(implode("\n", split_values($edit['Amenities'] ?? ''))) ?></textarea></div>
                    <div class="col-6"><label class="d-flex gap-2 align-items-center"><input type="checkbox" name="IsFeatured" <?= !empty($edit['IsFeatured']) || !$edit ? 'checked' : '' ?>> Featured</label></div>
                    <div class="col-6"><label class="d-flex gap-2 align-items-center"><input type="checkbox" name="IsActive" <?= !isset($edit['IsActive']) || !empty($edit['IsActive']) ? 'checked' : '' ?>> Active</label></div>
                </div>
                <button class="btn btn-gold w-100 mt-4" type="submit">Save Property</button>
                <?php if ($edit): ?><a class="btn btn-outline-light rounded-0 w-100 mt-2" href="<?= h(site_url('admin/properties.php')) ?>">Add New</a><?php endif; ?>
            </form>
            <?php if ($gallery): ?>
                <h5 class="mt-4">Existing Gallery</h5>
                <div class="gallery-admin">
                    <?php foreach ($gallery as $image): ?>
                        <figure><img src="<?= h(image_url($image['ImageUrl'])) ?>" alt=""><button type="button" data-delete-gallery data-type="property" data-id="<?= (int)$image['Id'] ?>" data-csrf="<?= h(csrf_token()) ?>">&times;</button></figure>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-xl-7">
        <div class="admin-card p-4">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th>Image</th><th>Property</th><th>Price</th><th>Status</th><th class="text-end">Actions</th></tr></thead>
                    <tbody>
                    <?php foreach ($properties as $row): ?>
                        <tr>
                            <td><img src="<?= h(image_url($row['ThumbnailImage'] ?? '')) ?>" style="width:78px;height:54px;object-fit:cover" alt=""></td>
                            <td><?= h($row['Title']) ?><br><small class="text-secondary"><?= h($row['ProjectName'] ?? $row['AreaName'] ?? '') ?></small></td>
                            <td><?= h(money($row['Price'] ?? 0)) ?></td>
                            <td><?= h($row['Status']) ?></td>
                            <td class="text-end">
                                <a class="btn btn-sm btn-outline-warning rounded-0" href="<?= h(site_url('admin/properties.php?edit=' . (int)$row['Id'])) ?>">Edit</a>
                                <form method="post" class="d-inline" onsubmit="return confirm('Delete this property?')">
                                    <?= csrf_field() ?><input type="hidden" name="delete_id" value="<?= (int)$row['Id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger rounded-0">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
