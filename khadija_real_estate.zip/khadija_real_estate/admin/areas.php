<?php
$entity = 'areas';
require __DIR__ . '/manage-entity.php';
