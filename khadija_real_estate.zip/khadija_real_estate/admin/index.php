<?php
require_once dirname(__DIR__) . '/includes/config.php';
if (admin_logged_in()) {
    header('Location: ' . site_url('admin/dashboard.php'));
    exit;
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $email = trim((string)($_POST['email'] ?? ''));
    $password = (string)($_POST['password'] ?? '');
    $admin = db_fetch_one('SELECT * FROM `admin` WHERE `Email` = ? LIMIT 1', 's', [$email]);
    if ($admin && verify_admin_password($password, (string)$admin['Passwd']) && strtolower((string)$admin['Status']) !== 'inactive') {
        $_SESSION['admin_id'] = (int)$admin['Id'];
        header('Location: ' . site_url('admin/dashboard.php'));
        exit;
    }
    $error = 'Invalid email or password.';
}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Admin Login | Khadija Real Estate</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= h(site_url('assets/css/style.css')) ?>" rel="stylesheet">
    <link href="<?= h(site_url('assets/css/admin.css')) ?>" rel="stylesheet">
</head>
<body class="login-page">
<div class="login-box">
    <div class="brand mb-4"><span class="brand-mark">K</span><span><strong>KHADIJA</strong><small>ADMIN PANEL</small></span></div>
    <h1 class="display-title">Login</h1>
    <?= flash_message() ?>
    <?php if ($error): ?><div class="alert alert-danger"><?= h($error) ?></div><?php endif; ?>
    <form method="post">
        <?= csrf_field() ?>
        <div class="mb-3"><label class="form-label">Email</label><input class="form-control form-input" type="email" name="email" required></div>
        <div class="mb-3"><label class="form-label">Password</label><input class="form-control form-input" type="password" name="password" required></div>
        <button class="btn btn-gold w-100" type="submit">Login</button>
        <div class="mt-3"><a class="text-warning" href="<?= h(site_url('admin/forgot-password.php')) ?>">Forgot password?</a></div>
    </form>
</div>
</body>
</html>
