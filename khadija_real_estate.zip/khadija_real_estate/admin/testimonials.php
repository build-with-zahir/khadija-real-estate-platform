<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (isset($_POST['delete_id'])) {
        db_execute('DELETE FROM `testimonial` WHERE `Id` = ?', 'i', [(int)$_POST['delete_id']]);
        set_flash('success', 'Testimonial deleted.');
        header('Location: ' . site_url('admin/testimonials.php'));
        exit;
    }
    $id = (int)($_POST['Id'] ?? 0);
    $data = [
        'ProjectId' => ($_POST['ProjectId'] ?? '') !== '' ? (int)$_POST['ProjectId'] : null,
        'ClientName' => trim((string)($_POST['ClientName'] ?? '')),
        'Review' => trim((string)($_POST['Review'] ?? '')),
        'Rating' => max(1, min(5, (int)($_POST['Rating'] ?? 5))),
    ];
    if ($id > 0) {
        db_execute('UPDATE `testimonial` SET `ProjectId` = ?, `ClientName` = ?, `Review` = ?, `Rating` = ? WHERE `Id` = ?', 'issii', [$data['ProjectId'], $data['ClientName'], $data['Review'], $data['Rating'], $id]);
        set_flash('success', 'Testimonial updated.');
    } else {
        db_execute('INSERT INTO `testimonial` (`ProjectId`, `ClientName`, `Review`, `Rating`, `CreatedAt`) VALUES (?, ?, ?, ?, NOW())', 'issi', [$data['ProjectId'], $data['ClientName'], $data['Review'], $data['Rating']]);
        set_flash('success', 'Testimonial added.');
    }
    header('Location: ' . site_url('admin/testimonials.php'));
    exit;
}

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$edit = $editId ? db_fetch_one('SELECT * FROM `testimonial` WHERE `Id` = ? LIMIT 1', 'i', [$editId]) : null;
$projects = fetch_projects();
$rows = db_fetch_all('SELECT t.*, p.`ProjectName` FROM `testimonial` t LEFT JOIN `project` p ON p.`Id` = t.`ProjectId` ORDER BY t.`CreatedAt` DESC');
$pageTitle = 'Testimonials';
$heading = 'Testimonials';
require __DIR__ . '/includes/header.php';
?>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="admin-card p-4">
            <h3 class="display-title"><?= $edit ? 'Edit' : 'Add' ?> Testimonial</h3>
            <form method="post">
                <?= csrf_field() ?>
                <input type="hidden" name="Id" value="<?= (int)($edit['Id'] ?? 0) ?>">
                <div class="mb-3"><label>Project</label><select class="form-select" name="ProjectId"><option value="">None</option><?php foreach ($projects as $project): ?><option value="<?= (int)$project['Id'] ?>" <?= (string)($edit['ProjectId'] ?? '') === (string)$project['Id'] ? 'selected' : '' ?>><?= h($project['ProjectName']) ?></option><?php endforeach; ?></select></div>
                <div class="mb-3"><label>Client Name</label><input class="form-control" name="ClientName" value="<?= h($edit['ClientName'] ?? '') ?>" required></div>
                <div class="mb-3"><label>Rating</label><input class="form-control" type="number" min="1" max="5" name="Rating" value="<?= h((string)($edit['Rating'] ?? 5)) ?>"></div>
                <div class="mb-3"><label>Review</label><textarea class="form-control" name="Review" rows="5" required><?= h($edit['Review'] ?? '') ?></textarea></div>
                <button class="btn btn-gold w-100">Save</button>
            </form>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="admin-card p-4">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th>Client</th><th>Project</th><th>Rating</th><th class="text-end">Actions</th></tr></thead>
                    <tbody>
                    <?php foreach ($rows as $row): ?>
                        <tr>
                            <td><?= h($row['ClientName']) ?><br><small class="text-secondary"><?= h($row['Review']) ?></small></td>
                            <td><?= h($row['ProjectName'] ?? '-') ?></td>
                            <td><?= (int)$row['Rating'] ?>/5</td>
                            <td class="text-end">
                                <a class="btn btn-sm btn-outline-warning rounded-0" href="<?= h(site_url('admin/testimonials.php?edit=' . (int)$row['Id'])) ?>">Edit</a>
                                <form method="post" class="d-inline" onsubmit="return confirm('Delete this testimonial?')"><?= csrf_field() ?><input type="hidden" name="delete_id" value="<?= (int)$row['Id'] ?>"><button class="btn btn-sm btn-outline-danger rounded-0">Delete</button></form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
