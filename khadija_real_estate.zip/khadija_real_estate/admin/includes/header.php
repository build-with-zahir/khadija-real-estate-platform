<?php
require_once dirname(__DIR__, 2) . '/includes/config.php';
require_admin();
$admin = db_fetch_one('SELECT * FROM `admin` WHERE `Id` = ? LIMIT 1', 'i', [(int)$_SESSION['admin_id']]);
$currentAdmin = basename($_SERVER['SCRIPT_NAME'] ?? '');
$links = [
    'dashboard.php' => ['bi-speedometer2', 'Dashboard'],
    'areas.php' => ['bi-geo-alt', 'Areas'],
    'categories.php' => ['bi-grid', 'Categories'],
    'projects.php' => ['bi-buildings', 'Projects'],
    'properties.php' => ['bi-house-door', 'Properties'],
    'testimonials.php' => ['bi-star', 'Testimonials'],
    'inquiries.php' => ['bi-chat-left-text', 'Inquiries'],
    'company.php' => ['bi-gear', 'Company Info'],
];
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= h($pageTitle ?? 'Admin') ?> | Khadija Real Estate</title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=DM+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= h(site_url('assets/css/style.css')) ?>" rel="stylesheet">
    <link href="<?= h(site_url('assets/css/admin.css')) ?>" rel="stylesheet">
</head>
<body class="admin-body">
<div class="admin-shell">
    <aside class="admin-sidebar">
        <a class="brand" href="<?= h(site_url('admin/dashboard.php')) ?>">
            <span class="brand-mark">K</span>
            <span><strong>ADMIN</strong><small>KHADIJA</small></span>
        </a>
        <nav class="admin-nav">
            <?php foreach ($links as $file => $item): ?>
                <a class="<?= $currentAdmin === $file ? 'active' : '' ?>" href="<?= h(site_url('admin/' . $file)) ?>"><i class="bi <?= h($item[0]) ?>"></i><?= h($item[1]) ?></a>
            <?php endforeach; ?>
            <a href="<?= h(site_url()) ?>" target="_blank"><i class="bi bi-box-arrow-up-right"></i>View Site</a>
            <a href="<?= h(site_url('admin/logout.php')) ?>"><i class="bi bi-box-arrow-left"></i>Logout</a>
        </nav>
    </aside>
    <main class="admin-main">
        <div class="d-flex flex-wrap justify-content-between align-items-center gap-3 mb-4">
            <div>
                <h1 class="display-title mb-0"><?= h($heading ?? $pageTitle ?? 'Admin') ?></h1>
                <p class="text-secondary mb-0">Welcome, <?= h($admin['Full_Name'] ?? 'Admin') ?></p>
            </div>
        </div>
        <?= flash_message() ?>
