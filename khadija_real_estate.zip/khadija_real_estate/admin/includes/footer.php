    </main>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script>
document.querySelectorAll('[data-delete-gallery]').forEach(function (button) {
    button.addEventListener('click', function () {
        if (!confirm('Delete this image?')) return;
        var form = new FormData();
        form.append('type', button.dataset.type);
        form.append('id', button.dataset.id);
        form.append('_csrf', button.dataset.csrf);
        fetch('<?= h(site_url('admin/gallery-delete.php')) ?>', { method: 'POST', body: form })
            .then(function (response) { return response.json(); })
            .then(function (data) {
                if (data.ok) {
                    button.closest('figure').remove();
                } else {
                    alert(data.message || 'Unable to delete image.');
                }
            });
    });
});
</script>
</body>
</html>
