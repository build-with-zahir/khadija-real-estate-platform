<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['delete_id'])) {
    verify_csrf();
    db_execute('DELETE FROM `inquiry` WHERE `Id` = ?', 'i', [(int)$_POST['delete_id']]);
    set_flash('success', 'Inquiry deleted.');
    header('Location: ' . site_url('admin/inquiries.php'));
    exit;
}

$rows = db_fetch_all('SELECT i.*, p.`ProjectName` FROM `inquiry` i LEFT JOIN `project` p ON p.`Id` = i.`ProjectId` ORDER BY i.`CreatedAt` DESC');
$pageTitle = 'Inquiries';
$heading = 'Inquiries';
require __DIR__ . '/includes/header.php';
?>
<div class="admin-card p-4">
    <div class="table-responsive">
        <table class="table align-middle">
            <thead><tr><th>Name</th><th>Contact</th><th>Project</th><th>Message</th><th>Date</th><th></th></tr></thead>
            <tbody>
            <?php foreach ($rows as $row): ?>
                <tr>
                    <td><?= h($row['FullName']) ?></td>
                    <td><?= h($row['PhoneNumber']) ?><br><small class="text-secondary"><?= h($row['Email']) ?></small></td>
                    <td><?= h($row['ProjectName'] ?? '-') ?></td>
                    <td><?= h($row['Message']) ?></td>
                    <td><?= h($row['CreatedAt']) ?></td>
                    <td class="text-end"><form method="post" onsubmit="return confirm('Delete this inquiry?')"><?= csrf_field() ?><input type="hidden" name="delete_id" value="<?= (int)$row['Id'] ?>"><button class="btn btn-sm btn-outline-danger rounded-0">Delete</button></form></td>
                </tr>
            <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
