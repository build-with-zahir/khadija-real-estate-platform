<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_admin();

function option_selected($a, $b): string { return (string)$a === (string)$b ? 'selected' : ''; }

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    if (isset($_POST['delete_id'])) {
        $id = (int)$_POST['delete_id'];
        $project = db_fetch_one('SELECT * FROM `project` WHERE `Id` = ? LIMIT 1', 'i', [$id]);
        if ($project) {
            delete_local_upload($project['ThumbnailImage'] ?? '');
            foreach (db_fetch_all('SELECT `ImageUrl` FROM `projectimage` WHERE `ProjectId` = ?', 'i', [$id]) as $image) {
                delete_local_upload($image['ImageUrl'] ?? '');
            }
            db_execute('UPDATE `property` SET `ProjectId` = NULL WHERE `ProjectId` = ?', 'i', [$id]);
            db_execute('DELETE FROM `projectfeature` WHERE `ProjectId` = ?', 'i', [$id]);
            db_execute('DELETE FROM `projectimage` WHERE `ProjectId` = ?', 'i', [$id]);
            db_execute('DELETE FROM `project` WHERE `Id` = ?', 'i', [$id]);
        }
        set_flash('success', 'Project deleted.');
        header('Location: ' . site_url('admin/projects.php'));
        exit;
    }

    $id = (int)($_POST['Id'] ?? 0);
    $existing = $id ? db_fetch_one('SELECT * FROM `project` WHERE `Id` = ? LIMIT 1', 'i', [$id]) : null;
    $name = trim((string)($_POST['ProjectName'] ?? ''));
    $thumb = upload_single('thumbnail_file', 'uploads/projects', (string)($_POST['ThumbnailImage'] ?: ($existing['ThumbnailImage'] ?? '')));
    $data = [
        'AreaId' => (int)($_POST['AreaId'] ?? 0),
        'CategoryId' => ($_POST['CategoryId'] ?? '') !== '' ? (int)$_POST['CategoryId'] : null,
        'ProjectName' => $name,
        'Slug' => trim((string)($_POST['Slug'] ?? '')) ?: slugify($name),
        'Description' => trim((string)($_POST['Description'] ?? '')),
        'Address' => trim((string)($_POST['Address'] ?? '')),
        'ProjectType' => trim((string)($_POST['ProjectType'] ?? '')),
        'Status' => trim((string)($_POST['Status'] ?? '')),
        'GoogleMapLink' => trim((string)($_POST['GoogleMapLink'] ?? '')),
        'ThumbnailImage' => $thumb,
        'StartingPrice' => (string)(float)($_POST['StartingPrice'] ?? 0),
        'IsFeatured' => isset($_POST['IsFeatured']) ? 1 : 0,
        'StartDate' => $_POST['StartDate'] ?: date('Y-m-d'),
        'CompletionDate' => $_POST['CompletionDate'] ?: null,
    ];

    if ($id > 0) {
        $sets = implode(', ', array_map(fn($field) => "`$field` = ?", array_keys($data)));
        $params = array_values($data);
        $params[] = $id;
        db_execute("UPDATE `project` SET $sets WHERE `Id` = ?", str_repeat('s', count($data)) . 'i', $params);
        $projectId = $id;
        set_flash('success', 'Project updated.');
    } else {
        $cols = implode(', ', array_map(fn($field) => "`$field`", array_keys($data)));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        $projectId = db_execute("INSERT INTO `project` ($cols, `CreatedAt`) VALUES ($placeholders, NOW())", str_repeat('s', count($data)), array_values($data));
        set_flash('success', 'Project added.');
    }

    db_execute('DELETE FROM `projectfeature` WHERE `ProjectId` = ?', 'i', [$projectId]);
    foreach (split_values((string)($_POST['Features'] ?? '')) as $feature) {
        db_execute('INSERT INTO `projectfeature` (`ProjectId`, `FeatureName`) VALUES (?, ?)', 'is', [$projectId, $feature]);
    }

    $display = (int)db_fetch_value('SELECT COALESCE(MAX(`DisplayOrder`), -1) + 1 FROM `projectimage` WHERE `ProjectId` = ?', 'i', [$projectId]);
    foreach (upload_gallery('gallery', 'uploads/projects') as $image) {
        db_execute('INSERT INTO `projectimage` (`ProjectId`, `ImageUrl`, `DisplayOrder`) VALUES (?, ?, ?)', 'isi', [$projectId, $image, $display]);
        $display++;
    }

    header('Location: ' . site_url('admin/projects.php?edit=' . $projectId));
    exit;
}

$editId = isset($_GET['edit']) ? (int)$_GET['edit'] : 0;
$edit = $editId ? db_fetch_one('SELECT * FROM `project` WHERE `Id` = ? LIMIT 1', 'i', [$editId]) : null;
$features = $editId ? db_fetch_all('SELECT * FROM `projectfeature` WHERE `ProjectId` = ? ORDER BY `Id`', 'i', [$editId]) : [];
$gallery = $editId ? db_fetch_all('SELECT * FROM `projectimage` WHERE `ProjectId` = ? ORDER BY `DisplayOrder`, `Id`', 'i', [$editId]) : [];
$areas = db_fetch_all('SELECT * FROM `area` ORDER BY `AreaName`');
$categories = db_fetch_all('SELECT * FROM `category` ORDER BY `Name`');
$projects = fetch_projects();
$pageTitle = 'Projects';
$heading = 'Projects';
require __DIR__ . '/includes/header.php';
?>
<div class="row g-4">
    <div class="col-xl-5">
        <div class="admin-card p-4">
            <h3 class="display-title"><?= $edit ? 'Edit Project' : 'Add Project' ?></h3>
            <form method="post" enctype="multipart/form-data">
                <?= csrf_field() ?>
                <input type="hidden" name="Id" value="<?= (int)($edit['Id'] ?? 0) ?>">
                <div class="row g-3">
                    <div class="col-md-8"><label>Project Name</label><input class="form-control" name="ProjectName" value="<?= h($edit['ProjectName'] ?? '') ?>" required></div>
                    <div class="col-md-4"><label>Slug</label><input class="form-control" name="Slug" value="<?= h($edit['Slug'] ?? '') ?>"></div>
                    <div class="col-md-6"><label>Area</label><select class="form-select" name="AreaId" required><option value="">Select</option><?php foreach ($areas as $area): ?><option value="<?= (int)$area['Id'] ?>" <?= option_selected($edit['AreaId'] ?? '', $area['Id']) ?>><?= h($area['AreaName']) ?></option><?php endforeach; ?></select></div>
                    <div class="col-md-6"><label>Category</label><select class="form-select" name="CategoryId"><option value="">Select</option><?php foreach ($categories as $cat): ?><option value="<?= (int)$cat['Id'] ?>" <?= option_selected($edit['CategoryId'] ?? '', $cat['Id']) ?>><?= h($cat['Name']) ?></option><?php endforeach; ?></select></div>
                    <div class="col-12"><label>Description</label><textarea class="form-control" name="Description" rows="4"><?= h($edit['Description'] ?? '') ?></textarea></div>
                    <div class="col-12"><label>Address</label><input class="form-control" name="Address" value="<?= h($edit['Address'] ?? '') ?>"></div>
                    <div class="col-md-6"><label>Project Type</label><input class="form-control" name="ProjectType" value="<?= h($edit['ProjectType'] ?? 'Residential') ?>"></div>
                    <div class="col-md-6"><label>Status</label><select class="form-select" name="Status"><?php foreach (['Ongoing', 'Upcoming', 'Completed'] as $status): ?><option <?= option_selected($edit['Status'] ?? '', $status) ?>><?= h($status) ?></option><?php endforeach; ?></select></div>
                    <div class="col-md-6"><label>Starting Price</label><input class="form-control" type="number" step="0.01" name="StartingPrice" value="<?= h((string)($edit['StartingPrice'] ?? '')) ?>"></div>
                    <div class="col-md-3"><label>Start Date</label><input class="form-control" type="date" name="StartDate" value="<?= h(substr((string)($edit['StartDate'] ?? date('Y-m-d')), 0, 10)) ?>"></div>
                    <div class="col-md-3"><label>Completion</label><input class="form-control" type="date" name="CompletionDate" value="<?= h(substr((string)($edit['CompletionDate'] ?? ''), 0, 10)) ?>"></div>
                    <div class="col-12"><label>Google Map Link</label><input class="form-control" name="GoogleMapLink" value="<?= h($edit['GoogleMapLink'] ?? '') ?>"></div>
                    <div class="col-12"><label>Thumbnail path</label><input class="form-control" name="ThumbnailImage" value="<?= h($edit['ThumbnailImage'] ?? '') ?>"><input class="form-control mt-2" type="file" name="thumbnail_file" accept="image/*"></div>
                    <div class="col-12"><label>Gallery images</label><input class="form-control" type="file" name="gallery[]" accept="image/*" multiple></div>
                    <div class="col-12"><label>Features (one per line)</label><textarea class="form-control" name="Features" rows="4"><?= h(implode("\n", array_column($features, 'FeatureName'))) ?></textarea></div>
                    <div class="col-12"><label class="d-flex gap-2 align-items-center"><input type="checkbox" name="IsFeatured" <?= !empty($edit['IsFeatured']) || !$edit ? 'checked' : '' ?>> Featured</label></div>
                </div>
                <button class="btn btn-gold w-100 mt-4" type="submit">Save Project</button>
                <?php if ($edit): ?><a class="btn btn-outline-light rounded-0 w-100 mt-2" href="<?= h(site_url('admin/projects.php')) ?>">Add New</a><?php endif; ?>
            </form>
            <?php if ($gallery): ?>
                <h5 class="mt-4">Existing Gallery</h5>
                <div class="gallery-admin">
                    <?php foreach ($gallery as $image): ?>
                        <figure><img src="<?= h(image_url($image['ImageUrl'])) ?>" alt=""><button type="button" data-delete-gallery data-type="project" data-id="<?= (int)$image['Id'] ?>" data-csrf="<?= h(csrf_token()) ?>">&times;</button></figure>
                    <?php endforeach; ?>
                </div>
            <?php endif; ?>
        </div>
    </div>
    <div class="col-xl-7">
        <div class="admin-card p-4">
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th>Image</th><th>Project</th><th>Type</th><th>Status</th><th class="text-end">Actions</th></tr></thead>
                    <tbody>
                    <?php foreach ($projects as $row): ?>
                        <tr>
                            <td><img src="<?= h(image_url($row['ThumbnailImage'] ?? '')) ?>" style="width:78px;height:54px;object-fit:cover" alt=""></td>
                            <td><?= h($row['ProjectName']) ?><br><small class="text-secondary"><?= h($row['AreaName'] ?? '') ?></small></td>
                            <td><?= h($row['ProjectType']) ?></td>
                            <td><?= h($row['Status']) ?></td>
                            <td class="text-end">
                                <a class="btn btn-sm btn-outline-warning rounded-0" href="<?= h(site_url('admin/projects.php?edit=' . (int)$row['Id'])) ?>">Edit</a>
                                <form method="post" class="d-inline" onsubmit="return confirm('Delete this project?')">
                                    <?= csrf_field() ?><input type="hidden" name="delete_id" value="<?= (int)$row['Id'] ?>">
                                    <button class="btn btn-sm btn-outline-danger rounded-0">Delete</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
