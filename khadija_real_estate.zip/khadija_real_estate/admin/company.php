<?php
require_once dirname(__DIR__) . '/includes/config.php';
require_admin();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    verify_csrf();
    $existing = db_fetch_one('SELECT * FROM `companyinfo` ORDER BY `Id` ASC LIMIT 1');
    $logo = upload_single('logo_file', 'uploads/general', (string)($_POST['Logo'] ?: ($existing['Logo'] ?? '')));
    $data = [
        'CompanyName' => trim((string)($_POST['CompanyName'] ?? 'Khadija Real Estate')),
        'Logo' => $logo,
        'AboutUs' => trim((string)($_POST['AboutUs'] ?? '')),
        'Address' => trim((string)($_POST['Address'] ?? '')),
        'Phone' => trim((string)($_POST['Phone'] ?? '')),
        'Email' => trim((string)($_POST['Email'] ?? '')),
        'FacebookUrl' => trim((string)($_POST['FacebookUrl'] ?? '')),
        'InstagramUrl' => trim((string)($_POST['InstagramUrl'] ?? '')),
        'LinkedinUrl' => trim((string)($_POST['LinkedinUrl'] ?? '')),
        'GoogleMapEmbed' => trim((string)($_POST['GoogleMapEmbed'] ?? '')),
    ];
    if ($existing) {
        $sets = implode(', ', array_map(fn($field) => "`$field` = ?", array_keys($data)));
        $params = array_values($data);
        $params[] = (int)$existing['Id'];
        db_execute("UPDATE `companyinfo` SET $sets WHERE `Id` = ?", str_repeat('s', count($data)) . 'i', $params);
    } else {
        $cols = implode(', ', array_map(fn($field) => "`$field`", array_keys($data)));
        $placeholders = implode(', ', array_fill(0, count($data), '?'));
        db_execute("INSERT INTO `companyinfo` ($cols) VALUES ($placeholders)", str_repeat('s', count($data)), array_values($data));
    }
    set_flash('success', 'Company info saved.');
    header('Location: ' . site_url('admin/company.php'));
    exit;
}

$info = fetch_company();
$pageTitle = 'Company Info';
$heading = 'Company Info';
require __DIR__ . '/includes/header.php';
?>
<div class="admin-card p-4">
    <form method="post" enctype="multipart/form-data">
        <?= csrf_field() ?>
        <div class="row g-3">
            <div class="col-md-6"><label>Company Name</label><input class="form-control" name="CompanyName" value="<?= h($info['CompanyName'] ?? '') ?>"></div>
            <div class="col-md-6"><label>Phone</label><input class="form-control" name="Phone" value="<?= h($info['Phone'] ?? '') ?>"></div>
            <div class="col-md-6"><label>Email</label><input class="form-control" type="email" name="Email" value="<?= h($info['Email'] ?? '') ?>"></div>
            <div class="col-md-6"><label>Address</label><input class="form-control" name="Address" value="<?= h($info['Address'] ?? '') ?>"></div>
            <div class="col-12"><label>About Us</label><textarea class="form-control" name="AboutUs" rows="5"><?= h($info['AboutUs'] ?? '') ?></textarea></div>
            <div class="col-md-6"><label>Logo path</label><input class="form-control" name="Logo" value="<?= h($info['Logo'] ?? '') ?>"><input class="form-control mt-2" type="file" name="logo_file" accept="image/*"></div>
            <div class="col-md-6"><label>Facebook URL</label><input class="form-control" name="FacebookUrl" value="<?= h($info['FacebookUrl'] ?? '') ?>"></div>
            <div class="col-md-6"><label>Instagram URL</label><input class="form-control" name="InstagramUrl" value="<?= h($info['InstagramUrl'] ?? '') ?>"></div>
            <div class="col-md-6"><label>LinkedIn URL</label><input class="form-control" name="LinkedinUrl" value="<?= h($info['LinkedinUrl'] ?? '') ?>"></div>
            <div class="col-12"><label>Google Map Embed</label><textarea class="form-control" name="GoogleMapEmbed" rows="5"><?= h($info['GoogleMapEmbed'] ?? '') ?></textarea></div>
        </div>
        <button class="btn btn-gold mt-4" type="submit">Save Settings</button>
    </form>
</div>
<?php require __DIR__ . '/includes/footer.php'; ?>
