<article class="property-card card-hover h-100">
    <div class="media">
        <img src="<?= h(image_url($property['ThumbnailImage'] ?? '')) ?>" alt="<?= h($property['Title'] ?? '') ?>">
        <span class="badge-gold position-absolute top-0 end-0 m-3"><?= (int)($property['Bedrooms'] ?? 0) ?> BHK</span>
    </div>
    <div class="p-4">
        <h4><?= h($property['Title'] ?? '') ?></h4>
        <p class="muted small mb-3"><i class="bi bi-buildings"></i> <?= h($property['ProjectName'] ?? $property['Address'] ?? 'Bharuch') ?></p>
        <div class="d-flex flex-wrap gap-3 small muted">
            <span><i class="bi bi-door-open"></i> <?= (int)($property['Bedrooms'] ?? 0) ?> Beds</span>
            <span><i class="bi bi-droplet"></i> <?= (int)($property['Bathrooms'] ?? 0) ?> Baths</span>
            <span><i class="bi bi-rulers"></i> <?= (int)($property['SquareFeet'] ?? 0) ?> Sq.ft</span>
        </div>
        <div class="d-flex align-items-center justify-content-between border-top mt-4 pt-3">
            <strong class="text-warning"><?= h(money($property['Price'] ?? 0)) ?></strong>
            <a class="gold-link" href="<?= h(property_link($property)) ?>">View Details</a>
        </div>
    </div>
</article>
