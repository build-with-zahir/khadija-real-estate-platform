<?php $company = $company ?? fetch_company(); ?>
</main>
<footer class="site-footer">
    <div class="footer-line"></div>
    <div class="container py-5">
        <div class="row g-5">
            <div class="col-lg-4">
                <a class="brand footer-brand" href="<?= h(site_url()) ?>">
                    <span class="brand-mark">K</span>
                    <span><strong>KHADIJA</strong><small>REAL ESTATE</small></span>
                </a>
                <p class="mt-4 text-white-50"><?= h($company['AboutUs'] ?: 'Premium real estate development across Bharuch. Quality construction, transparent dealings, and timely delivery.') ?></p>
                <div class="socials">
                    <a href="<?= h($company['FacebookUrl'] ?: '#') ?>">FB</a>
                    <a href="<?= h($company['InstagramUrl'] ?: '#') ?>">IG</a>
                    <a href="<?= h($company['LinkedinUrl'] ?: '#') ?>">IN</a>
                    <a href="https://wa.me/91<?= h(preg_replace('/\D+/', '', $company['Phone'] ?: '9998085007')) ?>">WA</a>
                </div>
            </div>
            <div class="col-md-4 col-lg-3 offset-lg-1">
                <h6>Quick Links</h6>
                <a href="<?= h(site_url()) ?>">Home</a>
                <a href="<?= h(site_url('about.php')) ?>">About Us</a>
                <a href="<?= h(site_url('projects.php')) ?>">Projects</a>
                <a href="<?= h(site_url('properties.php')) ?>">Properties</a>
                <a href="<?= h(site_url('contact.php')) ?>">Contact</a>
            </div>
            <div class="col-md-8 col-lg-4">
                <h6>Contact Us</h6>
                <p><i class="bi bi-geo-alt"></i> <?= h($company['Address'] ?: "BG Trader's Pachbatti") ?></p>
                <p><i class="bi bi-telephone"></i> <?= h($company['Phone'] ?: '99980 85007') ?></p>
                <p><i class="bi bi-envelope"></i> <?= h($company['Email'] ?: 'info@khadijarealestate.com') ?></p>
                <a class="btn btn-gold btn-sm mt-2" href="<?= h(site_url('contact.php')) ?>">Get In Touch</a>
            </div>
        </div>
    </div>
    <div class="footer-bottom">
        <div class="container d-flex flex-wrap justify-content-between gap-2">
            <span>&copy; <?= date('Y') ?> Khadija Real Estate. All rights reserved.</span>
            <span>Crafted with precision and elegance</span>
        </div>
    </div>
</footer>
<div class="lightbox" id="lightbox" aria-hidden="true">
    <button class="lightbox-close" type="button" data-lightbox-close>&times;</button>
    <button class="lightbox-nav lightbox-prev" type="button" data-lightbox-prev>&lsaquo;</button>
    <img src="" alt="Gallery image" id="lightboxImage">
    <button class="lightbox-nav lightbox-next" type="button" data-lightbox-next>&rsaquo;</button>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="<?= h(site_url('assets/js/main.js')) ?>"></script>
</body>
</html>
