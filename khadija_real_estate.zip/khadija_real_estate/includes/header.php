<?php
require_once __DIR__ . '/config.php';
$company = fetch_company();
$nav = [
    'index.php' => 'Home',
    'about.php' => 'About Us',
    'categories.php' => 'Categories',
    'areas.php' => 'Areas',
    'projects.php' => 'Projects',
    'properties.php' => 'Properties',
    'house-tours.php' => 'House Tours',
    'contact.php' => 'Contact',
];
$current = basename($_SERVER['SCRIPT_NAME'] ?? 'index.php');
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title><?= h($pageTitle ?? 'Khadija Real Estate') ?></title>
    <link rel="preconnect" href="https://fonts.googleapis.com">
    <link rel="preconnect" href="https://fonts.gstatic.com" crossorigin>
    <link href="https://fonts.googleapis.com/css2?family=Cormorant+Garamond:wght@400;600;700&family=DM+Sans:wght@300;400;500;600;700;800&display=swap" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.3/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdn.jsdelivr.net/npm/bootstrap-icons@1.11.3/font/bootstrap-icons.css" rel="stylesheet">
    <link href="<?= h(site_url('assets/css/style.css')) ?>" rel="stylesheet">
</head>
<body>
<header class="site-header fixed-top">
    <nav class="navbar navbar-expand-lg navbar-dark">
        <div class="container">
            <a class="navbar-brand brand" href="<?= h(site_url()) ?>">
                <span class="brand-mark">K</span>
                <span><strong>KHADIJA</strong><small>REAL ESTATE</small></span>
            </a>
            <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#mainNav" aria-controls="mainNav" aria-expanded="false" aria-label="Toggle navigation">
                <span class="navbar-toggler-icon"></span>
            </button>
            <div class="collapse navbar-collapse" id="mainNav">
                <ul class="navbar-nav ms-auto align-items-lg-center">
                    <?php foreach ($nav as $file => $label): ?>
                        <li class="nav-item"><a class="nav-link <?= $current === $file ? 'active' : '' ?>" href="<?= h(site_url($file === 'index.php' ? '' : $file)) ?>"><?= h($label) ?></a></li>
                    <?php endforeach; ?>
                    <li class="nav-item ms-lg-3"><a class="btn btn-gold btn-sm" href="<?= h(site_url('contact.php')) ?>">Enquire Now</a></li>
                </ul>
            </div>
        </div>
    </nav>
</header>
<main>
