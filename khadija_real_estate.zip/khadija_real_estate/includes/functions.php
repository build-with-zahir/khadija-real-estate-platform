<?php
declare(strict_types=1);

function h(?string $value): string
{
    return htmlspecialchars((string)$value, ENT_QUOTES, 'UTF-8');
}

function db_stmt(string $sql, string $types = '', array $params = []): mysqli_stmt
{
    $stmt = db()->prepare($sql);
    if ($types !== '' && $params) {
        $refs = [];
        foreach ($params as $key => $value) {
            $refs[$key] = &$params[$key];
        }
        $stmt->bind_param($types, ...$refs);
    }
    $stmt->execute();
    return $stmt;
}

function db_fetch_all(string $sql, string $types = '', array $params = []): array
{
    $stmt = db_stmt($sql, $types, $params);
    $result = $stmt->get_result();
    return $result ? $result->fetch_all(MYSQLI_ASSOC) : [];
}

function db_fetch_one(string $sql, string $types = '', array $params = []): ?array
{
    $rows = db_fetch_all($sql, $types, $params);
    return $rows[0] ?? null;
}

function db_fetch_value(string $sql, string $types = '', array $params = [])
{
    $row = db_fetch_one($sql, $types, $params);
    if (!$row) {
        return null;
    }
    return array_values($row)[0] ?? null;
}

function db_execute(string $sql, string $types = '', array $params = []): int
{
    $stmt = db_stmt($sql, $types, $params);
    return db()->insert_id ?: $stmt->affected_rows;
}

function table_exists(string $table): bool
{
    $count = (int)db_fetch_value(
        'SELECT COUNT(*) FROM information_schema.TABLES WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ?',
        's',
        [$table]
    );
    return $count > 0;
}

function column_exists(string $table, string $column): bool
{
    $count = (int)db_fetch_value(
        'SELECT COUNT(*) FROM information_schema.COLUMNS WHERE TABLE_SCHEMA = DATABASE() AND TABLE_NAME = ? AND COLUMN_NAME = ?',
        'ss',
        [$table, $column]
    );
    return $count > 0;
}

function ensure_propertyimage_schema(): void
{
    db_execute(
        'CREATE TABLE IF NOT EXISTS `propertyimage` (
            `Id` INT AUTO_INCREMENT PRIMARY KEY,
            `PropertyId` INT NOT NULL,
            `ImageUrl` VARCHAR(255) NOT NULL,
            `DisplayOrder` INT DEFAULT 0,
            `CreatedAt` DATETIME DEFAULT CURRENT_TIMESTAMP,
            INDEX (`PropertyId`)
        ) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci'
    );

    if (!column_exists('property', 'GalleryImages')) {
        return;
    }

    $properties = db_fetch_all(
        "SELECT `Id`, `GalleryImages` FROM `property` WHERE COALESCE(`GalleryImages`, '') <> ''"
    );
    foreach ($properties as $property) {
        $propertyId = (int)$property['Id'];
        $existing = (int)db_fetch_value(
            'SELECT COUNT(*) FROM `propertyimage` WHERE `PropertyId` = ?',
            'i',
            [$propertyId]
        );
        if ($existing > 0) {
            continue;
        }
        $images = split_values((string)$property['GalleryImages']);
        foreach ($images as $order => $image) {
            db_execute(
                'INSERT INTO `propertyimage` (`PropertyId`, `ImageUrl`, `DisplayOrder`) VALUES (?, ?, ?)',
                'isi',
                [$propertyId, $image, $order]
            );
        }
    }
}

function split_values(?string $value): array
{
    if (!$value) {
        return [];
    }
    $parts = preg_split('/[\r\n,]+/', $value);
    return array_values(array_filter(array_map('trim', $parts ?: [])));
}

function money($amount): string
{
    $number = (float)$amount;
    if ($number <= 0) {
        return 'Price on request';
    }
    return 'Rs ' . number_format($number, 0);
}

function slugify(string $value): string
{
    $value = strtolower(trim($value));
    $value = preg_replace('/[^a-z0-9]+/', '-', $value) ?? '';
    return trim($value, '-') ?: 'item';
}

function image_url(?string $path, string $fallback = 'assets/images/placeholder.svg'): string
{
    $path = trim((string)$path);
    if ($path === '') {
        return site_url($fallback);
    }

    $path = str_replace('\\', '/', $path);
    if (preg_match('#^https?://#i', $path)) {
        $parts = parse_url($path);
        $host = strtolower($parts['host'] ?? '');
        $remotePath = $parts['path'] ?? '';
        if (($host === 'localhost' || $host === '127.0.0.1') && preg_match('#/uploads/(.+)$#', $remotePath, $m)) {
            return site_url('uploads/' . $m[1]);
        }
        return $path;
    }

    if (preg_match('#/uploads/(.+)$#', $path, $m)) {
        return site_url('uploads/' . $m[1]);
    }

    return site_url(ltrim($path, '/'));
}

function local_upload_path(string $relative): string
{
    $relative = trim(str_replace('\\', '/', $relative), '/');
    return PROJECT_ROOT . DIRECTORY_SEPARATOR . str_replace('/', DIRECTORY_SEPARATOR, $relative);
}

function delete_local_upload(?string $path): void
{
    $path = trim((string)$path);
    if ($path === '') {
        return;
    }
    $path = str_replace('\\', '/', $path);
    if (preg_match('#/uploads/(.+)$#', $path, $m)) {
        $path = 'uploads/' . $m[1];
    }
    $path = ltrim($path, '/');
    if (strpos($path, 'uploads/') !== 0) {
        return;
    }

    $full = local_upload_path($path);
    $uploadsRoot = realpath(PROJECT_ROOT . DIRECTORY_SEPARATOR . 'uploads');
    $targetDir = realpath(dirname($full));
    if ($uploadsRoot && $targetDir && strpos($targetDir, $uploadsRoot) === 0 && is_file($full)) {
        @unlink($full);
    }
}

function upload_single(string $field, string $dir, string $existing = ''): string
{
    if (!isset($_FILES[$field]) || ($_FILES[$field]['error'] ?? UPLOAD_ERR_NO_FILE) === UPLOAD_ERR_NO_FILE) {
        return $existing;
    }
    return upload_file_value($_FILES[$field]['name'], $_FILES[$field]['tmp_name'], (int)$_FILES[$field]['error'], (int)$_FILES[$field]['size'], $dir, $existing);
}

function upload_file_value(string $name, string $tmpName, int $error, int $size, string $dir, string $existing = ''): string
{
    if ($error !== UPLOAD_ERR_OK) {
        return $existing;
    }
    $ext = strtolower(pathinfo($name, PATHINFO_EXTENSION));
    $allowed = ['jpg', 'jpeg', 'png', 'webp', 'gif'];
    if (!in_array($ext, $allowed, true) || $size > 5 * 1024 * 1024) {
        return $existing;
    }

    $relativeDir = trim($dir, '/');
    $targetDir = local_upload_path($relativeDir);
    if (!is_dir($targetDir)) {
        mkdir($targetDir, 0775, true);
    }
    $file = date('YmdHis') . '-' . bin2hex(random_bytes(6)) . '.' . $ext;
    $relative = $relativeDir . '/' . $file;
    if (move_uploaded_file($tmpName, local_upload_path($relative))) {
        return $relative;
    }
    return $existing;
}

function upload_gallery(string $field, string $dir): array
{
    if (!isset($_FILES[$field]) || !is_array($_FILES[$field]['name'])) {
        return [];
    }
    $uploaded = [];
    foreach ($_FILES[$field]['name'] as $index => $name) {
        $path = upload_file_value(
            (string)$name,
            (string)$_FILES[$field]['tmp_name'][$index],
            (int)$_FILES[$field]['error'][$index],
            (int)$_FILES[$field]['size'][$index],
            $dir
        );
        if ($path !== '') {
            $uploaded[] = $path;
        }
    }
    return $uploaded;
}

function csrf_token(): string
{
    if (empty($_SESSION['_csrf'])) {
        $_SESSION['_csrf'] = bin2hex(random_bytes(24));
    }
    return $_SESSION['_csrf'];
}

function csrf_field(): string
{
    return '<input type="hidden" name="_csrf" value="' . h(csrf_token()) . '">';
}

function verify_csrf(): void
{
    $token = $_POST['_csrf'] ?? '';
    if (!is_string($token) || !hash_equals($_SESSION['_csrf'] ?? '', $token)) {
        http_response_code(419);
        exit('Invalid form token.');
    }
}

function set_flash(string $type, string $message): void
{
    $_SESSION['_flash'] = ['type' => $type, 'message' => $message];
}

function flash_message(): string
{
    if (empty($_SESSION['_flash'])) {
        return '';
    }
    $flash = $_SESSION['_flash'];
    unset($_SESSION['_flash']);
    return '<div class="alert alert-' . h($flash['type']) . ' alert-dismissible fade show" role="alert">'
        . h($flash['message'])
        . '<button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button></div>';
}

function fetch_company(): array
{
    $row = db_fetch_one('SELECT * FROM `companyinfo` ORDER BY `Id` ASC LIMIT 1');
    return $row ?: [
        'CompanyName' => 'Khadija Real Estate',
        'Logo' => '',
        'AboutUs' => 'Premium real estate development across Bharuch with quality construction, transparent deals, and timely delivery.',
        'Address' => "BG Trader's Pachbatti",
        'Phone' => '99980 85007',
        'Email' => 'info@khadijarealestate.com',
        'FacebookUrl' => '#',
        'InstagramUrl' => '#',
        'LinkedinUrl' => '#',
        'GoogleMapEmbed' => '',
    ];
}

function fetch_projects(string $where = '', string $types = '', array $params = [], int $limit = 0): array
{
    $sql = 'SELECT p.*, a.`AreaName`, a.`City`, c.`Name` AS `CategoryName`
            FROM `project` p
            LEFT JOIN `area` a ON a.`Id` = p.`AreaId`
            LEFT JOIN `category` c ON c.`Id` = p.`CategoryId`';
    if ($where !== '') {
        $sql .= ' WHERE ' . $where;
    }
    $sql .= ' ORDER BY p.`IsFeatured` DESC, p.`CreatedAt` DESC';
    if ($limit > 0) {
        $sql .= ' LIMIT ' . (int)$limit;
    }
    return db_fetch_all($sql, $types, $params);
}

function fetch_properties(string $where = '', string $types = '', array $params = [], int $limit = 0): array
{
    $sql = 'SELECT pr.*, p.`ProjectName`, a.`AreaName`, c.`Name` AS `CategoryName`
            FROM `property` pr
            LEFT JOIN `project` p ON p.`Id` = pr.`ProjectId`
            LEFT JOIN `area` a ON a.`Id` = pr.`AreaId`
            LEFT JOIN `category` c ON c.`Id` = pr.`CategoryId`';
    if ($where !== '') {
        $sql .= ' WHERE ' . $where;
    }
    $sql .= ' ORDER BY pr.`IsFeatured` DESC, pr.`CreatedAt` DESC';
    if ($limit > 0) {
        $sql .= ' LIMIT ' . (int)$limit;
    }
    return db_fetch_all($sql, $types, $params);
}

function fetch_project_gallery(int $projectId, ?string $thumbnail = ''): array
{
    $images = [];
    if ($thumbnail) {
        $images[] = $thumbnail;
    }
    $rows = db_fetch_all(
        'SELECT `ImageUrl` FROM `projectimage` WHERE `ProjectId` = ? ORDER BY `DisplayOrder`, `Id`',
        'i',
        [$projectId]
    );
    foreach ($rows as $row) {
        if (!in_array($row['ImageUrl'], $images, true)) {
            $images[] = $row['ImageUrl'];
        }
    }
    return $images;
}

function fetch_property_gallery(array $property): array
{
    $images = [];
    if (!empty($property['ThumbnailImage'])) {
        $images[] = $property['ThumbnailImage'];
    }
    if (table_exists('propertyimage')) {
        $rows = db_fetch_all(
            'SELECT `ImageUrl` FROM `propertyimage` WHERE `PropertyId` = ? ORDER BY `DisplayOrder`, `Id`',
            'i',
            [(int)$property['Id']]
        );
        foreach ($rows as $row) {
            if (!in_array($row['ImageUrl'], $images, true)) {
                $images[] = $row['ImageUrl'];
            }
        }
    } elseif (!empty($property['GalleryImages'])) {
        foreach (split_values((string)$property['GalleryImages']) as $image) {
            if (!in_array($image, $images, true)) {
                $images[] = $image;
            }
        }
    }
    return $images;
}

function fetch_project_features(int $projectId): array
{
    return db_fetch_all(
        'SELECT * FROM `projectfeature` WHERE `ProjectId` = ? ORDER BY `Id`',
        'i',
        [$projectId]
    );
}

function project_link(array $project): string
{
    $slug = $project['Slug'] ?: slugify((string)$project['ProjectName']);
    return site_url('project-details.php?slug=' . rawurlencode($slug));
}

function property_link(array $property): string
{
    return site_url('property-details.php?id=' . (int)$property['Id']);
}

function render_page_hero(string $title, string $crumb = '', string $image = ''): void
{
    ?>
    <section class="page-hero" style="background-image:url('<?= h(image_url($image, 'assets/images/hero-fallback.svg')) ?>')">
        <div class="page-hero__overlay"></div>
        <div class="container position-relative">
            <h1><?= h($title) ?></h1>
            <p><a href="<?= h(site_url()) ?>">Home</a> / <span><?= h($crumb ?: $title) ?></span></p>
        </div>
    </section>
    <?php
}

function handle_inquiry(?int $projectId = null): void
{
    if ($_SERVER['REQUEST_METHOD'] !== 'POST' || !isset($_POST['inquiry_submit'])) {
        return;
    }
    verify_csrf();
    $fullName = trim((string)($_POST['FullName'] ?? ''));
    $email = trim((string)($_POST['Email'] ?? ''));
    $phone = trim((string)($_POST['PhoneNumber'] ?? ''));
    $message = trim((string)($_POST['Message'] ?? ''));
    $postedProject = isset($_POST['ProjectId']) && $_POST['ProjectId'] !== '' ? (int)$_POST['ProjectId'] : $projectId;

    if ($fullName === '' || $phone === '' || $message === '') {
        set_flash('danger', 'Please fill name, phone and message.');
        return;
    }

    db_execute(
        'INSERT INTO `inquiry` (`FullName`, `Email`, `PhoneNumber`, `Message`, `ProjectId`, `CreatedAt`) VALUES (?, ?, ?, ?, ?, NOW())',
        'ssssi',
        [$fullName, $email, $phone, $message, $postedProject]
    );
    set_flash('success', 'Thank you. Your inquiry has been submitted.');
    header('Location: ' . ($_SERVER['REQUEST_URI'] ?? site_url('contact.php')));
    exit;
}

function inquiry_form(?int $projectId = null): void
{
    ?>
    <form method="post" class="inquiry-form">
        <?= csrf_field() ?>
        <input type="hidden" name="inquiry_submit" value="1">
        <?php if ($projectId): ?>
            <input type="hidden" name="ProjectId" value="<?= (int)$projectId ?>">
        <?php endif; ?>
        <div class="row g-3">
            <div class="col-md-6"><input class="form-control form-input" name="FullName" placeholder="Full name" required></div>
            <div class="col-md-6"><input class="form-control form-input" name="PhoneNumber" placeholder="Phone number" required></div>
            <div class="col-12"><input class="form-control form-input" type="email" name="Email" placeholder="Email address"></div>
            <div class="col-12"><textarea class="form-control form-input" name="Message" rows="4" placeholder="Tell us what you are looking for" required></textarea></div>
            <div class="col-12"><button class="btn btn-gold w-100" type="submit">Submit Inquiry</button></div>
        </div>
    </form>
    <?php
}

function admin_logged_in(): bool
{
    return !empty($_SESSION['admin_id']);
}

function require_admin(): void
{
    if (!admin_logged_in()) {
        header('Location: ' . site_url('admin/index.php'));
        exit;
    }
}

function verify_admin_password(string $plain, string $stored): bool
{
    if ($stored === '') {
        return false;
    }
    return password_verify($plain, $stored)
        || hash_equals($stored, $plain)
        || hash_equals($stored, md5($plain));
}
