<a class="project-card card-hover d-block" href="<?= h(project_link($project)) ?>">
    <div class="media">
        <img src="<?= h(image_url($project['ThumbnailImage'] ?? '')) ?>" alt="<?= h($project['ProjectName'] ?? '') ?>">
        <?php if (!empty($project['IsFeatured'])): ?><span class="badge-gold position-absolute top-0 start-0 m-3">Featured</span><?php endif; ?>
    </div>
    <div class="p-4">
        <div class="d-flex align-items-center justify-content-between gap-2 mb-3">
            <span class="badge-soft"><?= h($project['CategoryName'] ?? $project['ProjectType'] ?? 'Project') ?></span>
            <small class="muted"><?= h($project['AreaName'] ?? '') ?></small>
        </div>
        <h4 class="mb-2"><?= h($project['ProjectName'] ?? '') ?></h4>
        <p class="muted small mb-3"><i class="bi bi-geo-alt"></i> <?= h($project['Address'] ?? $project['AreaName'] ?? 'Bharuch') ?></p>
        <div class="d-flex align-items-center justify-content-between border-top pt-3">
            <strong class="text-warning">Starting <?= h(money($project['StartingPrice'] ?? 0)) ?></strong>
            <i class="bi bi-arrow-right text-warning"></i>
        </div>
    </div>
</a>
